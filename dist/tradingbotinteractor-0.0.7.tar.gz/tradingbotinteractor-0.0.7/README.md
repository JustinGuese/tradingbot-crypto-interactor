actually controls
https://github.com/JustinGuese/tradingbot-crypto

python3 -m build

`from tradinghandler.trading import TradingInteractor`

`ti = TradingInteractor("ACCOUNTNAME")`