actually controls
https://github.com/JustinGuese/tradingbot-crypto

`from tradinghandler.trading import TradingInteractor`

`ti = TradingInteractor("ACCOUNTNAME")`