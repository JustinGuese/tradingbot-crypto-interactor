actually controls
https://github.com/JustinGuese/tradingbot-crypto